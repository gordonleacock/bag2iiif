# Test Fixtures

These fixtures are taken from the the Presentation API specifications under <http://iiif.io/api/presentation/2.0/example/fixtures> or <https://github.com/IIIF/iiif.io/tree/master/source/api/presentation/2.1/example/fixtures>.
